
<!DOCTYPE html>
<html lang="id">
<head>
	<title>Cetak - Hasil Perhitungan AHP</title>
	<link rel="stylesheet" href="<?php echo base_url('assets')?>/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<link rel="stylesheet" href="<?php echo base_url('assets')?>/dist/css/adminlte.min.css">
	<script src="<?php echo base_url('assets')?>/plugins/jquery/jquery.min.js"></script>
</head>
<body>
	<h4><center>HASIL PERHITUNGAN SISTEM PENDUKUNG KEPUTUSAN<br>METODE AHP</center></h4><hr>
	<div id="tctk"></div>
</body>
</html>